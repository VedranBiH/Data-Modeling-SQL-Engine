
public class main {

	public static void main(String[] args) {
		Parser p = new Parser();
		p.parse();

	}

}
