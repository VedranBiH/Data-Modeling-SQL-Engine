import java.util.*;


public class Parser {

	private Queue<Token> parseQueue = new LinkedList<Token>();
	boolean isReject = false;
	
	
	public void parse()
	{
		Token tk = new Token();
		tk.setToken("SELECT");
		tk.setKeyword();
		parseQueue.add(tk);
		
		tk = new Token();
		tk.setToken("*");
		parseQueue.add(tk);
		
		tk = new Token();
		tk.setToken("FROM");
		tk.setKeyword();
		parseQueue.add(tk);
		
		tk = new Token();
		tk.setToken("A");
		tk.setKeyword();
		parseQueue.add(tk);
		
		tk = new Token();
		tk.setToken(";");
		tk.setKeyword();
		parseQueue.add(tk);
		
		A();
		
		if(isReject)
		{
			System.out.println("REJECT");
		}
		else
		{
			System.out.println("ACCEPT");
		}
	}
	private void A() // A -> aBCeEFGI;
	{
		if(getCurrentToken("SELECT"))
		{
			parseQueue.poll();
			B();
			C();
			if(getCurrentToken("FROM"))
			{
				parseQueue.poll();
				
				E();
				F();
				G();
				I();
				
				if(getCurrentToken(";"))
				{
					parseQueue.poll();
				}
				else
				{
					isReject = true;
				}
			}
			else
			{
				isReject = true;
			}
		}
		else
		{
			isReject = true;
		}
	}
	private void B() // B -> b | @
	{
		if(getCurrentToken("DISTINCT"))
		{
			parseQueue.poll();
		}
		else
		{
			return;
		}
	}
	private void C() // C -> * | (D)C'
	{
		if(getCurrentToken("*"))
		{
			parseQueue.poll();
		}
		else if(getCurrentToken("("))
		{
			D();
			
			if(getCurrentToken(")"))
			{
				parseQueue.poll();
			}
			else
			{
				isReject = true;
			}
			
			CP();
		}
		else
		{
			isReject = true;
		}
	}
	private void CP() // C' -> fg | @
	{
		if(getCurrentToken("AS"))
		{
			if(parseQueue.peek().isID())
			{
				parseQueue.poll();
			}
			else
			{
				isReject = true;
			}
		}
		else
		{
			return;
		}
	}
	private void D() // D -> hJD' | D''
	{
		if(parseQueue.peek().isID())
		{
			parseQueue.poll();
			
			J();
			
			DP();
		}
		else if(parseQueue.peek().isKeyword())
		{
			DPP();
		}
		else
		{
			isReject = true;
		}
		
	}
	private void DP() // DP-> ,D | @
	{
		if(getCurrentToken(","))
		{
			D();
		}
		else
		{
			return;
		}
	}
	private void DPP() //DPP -> d(D''')
	{
		if(parseQueue.peek().isKeyword())
		{
			parseQueue.poll();
			
			if(getCurrentToken("("))
			{
				parseQueue.poll();
			}
			else
			{
				isReject = true;
			}
			
			DPPP();
			
			if(getCurrentToken(")"))
			{
				parseQueue.poll();
			}
			else
			{
				isReject = true;
			}
		}
		else
		{
			isReject = true;
		}
	}
	private void DPPP() //DPPP -> * | c
	{
		if(getCurrentToken("*"))
		{
			parseQueue.poll();
		}
		else if(parseQueue.peek().isID())
		{
			parseQueue.poll();
		}
		else
		{
			isReject = true;
		}
	}
	private void E() // E -> hE'
	{
		if(parseQueue.peek().isID())
		{
			parseQueue.poll();
			
			EP();
		}
		else
		{
			isReject = true;
		}
	}
	private void EP() // EP -> ,E | @
	{
		if(getCurrentToken(","))
		{
			parseQueue.poll();
			
			E();
		}
		else
		{
			return;
		}
	}
	private void F() // F -> iF' | @
	{
		if(getCurrentToken("WHERE"))
		{
			parseQueue.poll();
			FP();
		}
		else
		{
			return;
		}
	}
	private void FP() //FP -> cjk | @
	{
		if(parseQueue.peek().isID())
		{
			parseQueue.poll();
			
			if(parseQueue.peek().isSymbol())
			{
				parseQueue.poll();
			}
			else
			{
				isReject = true;
			}
			if(parseQueue.peek().isLiteral())
			{
				parseQueue.poll();
			}
			else
			{
				isReject = true;
			}
		}
		else
		{
			return;
		}
	}
	private void G() // G -> lH(G') | @
	{
		if(getCurrentToken("GROUP BY"))
		{
			parseQueue.poll();
			
			H();
			
			if(getCurrentToken("("))
			{
				parseQueue.poll();
			}
			else
			{
				isReject = true;
			}
			GP();
			
			if(getCurrentToken(")"))
			{
				parseQueue.poll();
			}
			else
			{
				isReject = true;
			}
		}
		else
		{
			return;
		}
	}
	private void GP() // GP -> JcG''
	{
		J();
		
		if(parseQueue.peek().isID())
		{
			parseQueue.poll();
		}
		else
		{
			isReject= true;
		}
		
		GPP();
		
	}
	private void GPP() // GPP -> ,G' | @ 
	{
		if(getCurrentToken(","))
		{
			parseQueue.poll();
			
			GP();
		}
		else
		{
			return;
		}
	}
	private void H() // H -> m | @
	{
		if(parseQueue.peek().isID())
		{
			parseQueue.poll();
		}
		else
		{
			return;
		}
	}
	private void I() // I -> nI'
	{
		if(parseQueue.peek().isKeyword())
		{
			parseQueue.poll();
			IP();
		}
		else
		{
			isReject = true;
		}
	}
	private void IP() // IP -> d(c)jk
	{
		if(parseQueue.peek().isKeyword())
		{
			parseQueue.poll();
			if(getCurrentToken("("))
			{
				parseQueue.poll();
			}
			else
			{
				isReject = true;
			}
			
			if(parseQueue.peek().isID())
			{
				parseQueue.poll();
			}
			else
			{
				isReject = true;
			}
			
			if(getCurrentToken("("))
			{
				parseQueue.poll();
			}
			else
			{
				isReject = true;
			}
			if(parseQueue.peek().isSymbol())
			{
				parseQueue.poll();
			}
			else
			{
				isReject = true;
			}
			if(parseQueue.peek().isLiteral())
			{
				parseQueue.poll();
			}
			else
			{
				isReject = true;
			}
		}
	}
	private void J() // J -> .c | @
	{
		if(getCurrentToken("."))
		{
			parseQueue.poll();
			
			if(parseQueue.peek().isID())
			{
				parseQueue.poll();
			}
			else
			{
				isReject = true;
			}
		}
		else
		{
			return;
		}
	}
	private boolean getCurrentToken(String input)
	{
		return parseQueue.peek().getToken().equals(input);
	}
}


class Token
{
	private String token;
	private boolean isID;
	private boolean isSymbol;
	private boolean isKeyword;
	private boolean isLiteral;
	
	public Token()
	{
		isID = false;
		isSymbol = false;
		isKeyword = false;
	}
	public void setToken(String token)
	{
		this.token = token;
	}
	public void setID()
	{
		isID = true;
	}
	public void setSymbol()
	{
		isSymbol = true;
	}
	public void setKeyword()
	{
		isKeyword = true;
	}
	public void setLiteral()
	{
		isLiteral = true;
	}
	public boolean isLiteral()
	{
		return isLiteral;
	}
	public String getToken()
	{
		return token;
	}
	public boolean isID()
	{
		return isID;
	}
	public boolean isSymbol()
	{
		return isSymbol;
	}
	public boolean isKeyword()
	{
		return isKeyword;
	}
}