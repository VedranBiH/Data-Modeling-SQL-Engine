package newDM;

import java.util.Queue;

public class main {

	public static void main(String[] args) {
		
		lex lex = new lex();
		Queue<Token> q = lex.lexIt("SELECT * FROM A WHERE B = 3;");
		
		
		
		Parser p = new Parser(q);
		p.parse();

	}

}