package newDM;

import java.util.*;


public class Parser {

	private Queue<Token> parseQueue = new LinkedList<Token>();
	boolean isReject = false;
	
	Parser(Queue<Token> q)
	{
		parseQueue = q;

		Token tk = new Token("$",false,false,false,false);
		parseQueue.add(tk);
		
		System.out.println("Token\t" + "ID\t" + "Keyword\t" + "Literal\t" + "Symbol\t");
		System.out.println("***********************");
		while(!parseQueue.isEmpty())
		{
			
			System.out.println(parseQueue.peek().getToken() + "\t" + parseQueue.peek().isID() + "\t" + parseQueue.peek().isKeyword()+ "\t" + parseQueue.peek().isLiteral() + "\t" + parseQueue.peek().isSymbol());
			parseQueue.poll();
		}

	}
	public void parse() // SELECT (A,B) FROM C WHERE D = 5;
	{
		
		/*
		Token tk = new Token();
		tk.setToken("SELECT");
		tk.setKeyword();
		parseQueue.add(tk);
		
		tk = new Token();
		tk.setToken("(");
		tk.isSymbol();
		parseQueue.add(tk);
		
		tk = new Token();
		tk.setToken("A");
		tk.setID();
		parseQueue.add(tk);
		
		tk = new Token();
		tk.setToken(",");
		tk.isSymbol();
		parseQueue.add(tk);

		tk = new Token();
		tk.setToken("B");
		tk.setID();
		parseQueue.add(tk);

		tk = new Token();
		tk.setToken(")");
		tk.isSymbol();
		parseQueue.add(tk);
		
		tk = new Token();
		tk.setToken("FROM");
		tk.setKeyword();
		parseQueue.add(tk);
		
		tk = new Token();
		tk.setToken("C");
		tk.setID();
		parseQueue.add(tk);
		
		tk = new Token();
		tk.setToken("WHERE");
		tk.setKeyword();
		parseQueue.add(tk);
		
		tk = new Token();
		tk.setToken("D");
		tk.setID();
		parseQueue.add(tk);
		
		tk = new Token();
		tk.setToken("=");
		tk.setSymbol();
		parseQueue.add(tk);
		
		tk = new Token();
		tk.setToken("5");
		tk.setLiteral();
		parseQueue.add(tk);
		
		tk = new Token();
		tk.setToken(";");
		tk.setSymbol();
		parseQueue.add(tk);

		tk = new Token();
		tk.setToken("$");
		parseQueue.add(tk);
*/
		/*while(!parseQueue.isEmpty())
		{
			System.out.print(parseQueue.poll().getToken() + " ");
		}*/

		//A();

		if(isReject)
		{
			System.out.println("REJECT");
		}
		else
		{
			System.out.println("ACCEPT");
		}
	}
	private void A() // A -> aBCeEFGI;
	{
		if(!getCurrentToken("$"))
		{
			if(getCurrentToken("SELECT"))
			{
				parseQueue.poll();
				B();
				C();
				if(getCurrentToken("FROM"))
				{
					parseQueue.poll();
					
					E();
					F();
					G();
					I();
					
					if(getCurrentToken(";"))
					{
						parseQueue.poll();
					}
					else
					{
						isReject = true;
					}
				}
				else
				{
					isReject = true;
				}
			}
			else
			{
				isReject = true;
			}
		}
	}
	private void B() // B -> b | @
	{
		if(!getCurrentToken("$"))
		{
			if(getCurrentToken("DISTINCT"))
			{
				parseQueue.poll();
			}
			else
			{
				return;
			}
		}
	}
	private void C() // C -> * | (D)C'
	{
		if(!getCurrentToken("$"))
		{
			if(getCurrentToken("*"))
			{
				parseQueue.poll();
			}
			else if(getCurrentToken("("))
			{
				parseQueue.poll();
				
				D();
				
				if(getCurrentToken(")"))
				{
					parseQueue.poll();
				}
				else
				{
					
					isReject = true;
				}
				
				CP();
			}
			else
			{
				isReject = true;
			}
		}
	}
	private void CP() // C' -> fg | @
	{
		if(!getCurrentToken("$"))
		{
			if(getCurrentToken("AS"))
			{
				parseQueue.poll();
				
				if(parseQueue.peek().isID())
				{
					parseQueue.poll();
				}
				else
				{
					isReject = true;
				}
			}
			else
			{
				return;
			}
		}
	}
	private void D() // D -> hJD' | D''
	{
		if(!getCurrentToken("$"))
		{
			if(parseQueue.peek().isID())
			{
				parseQueue.poll();
				
				J();
				
				DP();
			}
			else if(parseQueue.peek().isKeyword())
			{
				DPP();
			}
			else
			{
				isReject = true;
			}
		}
	}
	private void DP() // DP-> ,D | @
	{
		if(!getCurrentToken("$"))
		{
			if(getCurrentToken(","))
			{
				parseQueue.poll();
				
				D();
			}
			else
			{
				return;
			}
		}
	}
	private void DPP() //DPP -> d(D''')
	{
		if(!getCurrentToken("$"))
		{
			if(parseQueue.peek().isKeyword())
			{
				parseQueue.poll();
				
				if(getCurrentToken("("))
				{
					parseQueue.poll();
				}
				else
				{
					isReject = true;
				}
				
				DPPP();
				
				if(getCurrentToken(")"))
				{
					parseQueue.poll();
				}
				else
				{
					isReject = true;
				}
			}
			else
			{
				isReject = true;
			}
		}
	}
	private void DPPP() //DPPP -> * | c
	{
		if(!getCurrentToken("$"))
		{
			if(getCurrentToken("*"))
			{
				parseQueue.poll();
			}
			else if(parseQueue.peek().isID())
			{
				parseQueue.poll();
			}
			else
			{
				isReject = true;
			}
		}
	}
	private void E() // E -> hE'
	{
		if(!getCurrentToken("$"))
		{
			if(parseQueue.peek().isID())
			{
				parseQueue.poll();
				
				EP();
			}
			else
			{
				isReject = true;
			}
		}
	}
	private void EP() // EP -> ,E | @
	{
		if(!getCurrentToken("$"))
		{
			if(getCurrentToken(","))
			{
				parseQueue.poll();
				
				E();
			}
			else
			{
				return;
			}
		}
	}
	private void F() // F -> iF' | @
	{
		if(!getCurrentToken("$"))
		{
			if(getCurrentToken("WHERE"))
			{
				parseQueue.poll();
				FP();
			}
			else
			{
				return;
			}
		}
	}
	private void FP() //FP -> cjk | @
	{
		if(!getCurrentToken("$"))
		{
			if(parseQueue.peek().isID())
			{
				parseQueue.poll();
				
				if(parseQueue.peek().isSymbol())
				{
					parseQueue.poll();
				}
				else
				{
					isReject = true;
				}
				if(parseQueue.peek().isLiteral())
				{
					parseQueue.poll();
				}
				else
				{
					isReject = true;
				}
			}
			else
			{
				return;
			}
		}
	}
	private void G() // G -> lH(G') | @
	{
		if(!getCurrentToken("$"))
		{
			if(getCurrentToken("GROUP BY"))
			{
				parseQueue.poll();
				
				H();
				
				if(getCurrentToken("("))
				{
					parseQueue.poll();
				}
				else
				{
					isReject = true;
				}
				GP();
				
				if(getCurrentToken(")"))
				{
					parseQueue.poll();
				}
				else
				{
					isReject = true;
				}
			}
			else
			{
				return;
			}
		}
	}
	private void GP() // GP -> JcG''
	{
		if(!getCurrentToken("$"))
		{
			J();
			
			if(parseQueue.peek().isID())
			{
				parseQueue.poll();
			}
			else
			{
				isReject= true;
			}
			
			GPP();
		}
		
	}
	private void GPP() // GPP -> ,G' | @ 
	{
		if(!getCurrentToken("$"))
		{
			if(getCurrentToken(","))
			{
				parseQueue.poll();
				
				GP();
			}
			else
			{
				return;
			}
		}
	}
	private void H() // H -> m | @
	{
		if(!getCurrentToken("$"))
		{
			if(parseQueue.peek().isID())
			{
				parseQueue.poll();
			}
			else
			{
				return;
			}
		}
	}
	private void I() // I -> nI'
	{
		if(!getCurrentToken("$"))
		{
			if(parseQueue.peek().isKeyword())
			{
				parseQueue.poll();
				IP();
			}
			else
			{
				return;
			}
		}
	}
	private void IP() // IP -> d(c)jk
	{
		if(!getCurrentToken("$"))
		{
			if(parseQueue.peek().isKeyword())
			{
				parseQueue.poll();
				if(getCurrentToken("("))
				{
					parseQueue.poll();
				}
				else
				{
					isReject = true;
				}
				
				if(parseQueue.peek().isID())
				{
					parseQueue.poll();
				}
				else
				{
					isReject = true;
				}
				
				if(getCurrentToken("("))
				{
					parseQueue.poll();
				}
				else
				{
					isReject = true;
				}
				if(parseQueue.peek().isSymbol())
				{
					parseQueue.poll();
				}
				else
				{
					isReject = true;
				}
				if(parseQueue.peek().isLiteral())
				{
					parseQueue.poll();
				}
				else
				{
					isReject = true;
				}
			}
		}
	}
	private void J() // J -> .c | @
	{
		if(!getCurrentToken("$"))
		{
			if(getCurrentToken("."))
			{
				parseQueue.poll();
				
				if(parseQueue.peek().isID())
				{
					
					parseQueue.poll();
				}
				else
				{
					System.out.println("HELLO FROM J");
					isReject = true;
				}
			}
			else
			{
				return;
			}
		}
	}
	private boolean getCurrentToken(String input)
	{
		return parseQueue.peek().getToken().equals(input);
	}
}


/*class Token
{
	private String token;
	private boolean isID;
	private boolean isSymbol;
	private boolean isKeyword;
	private boolean isLiteral;
	
	public Token()
	{
		isID = false;
		isSymbol = false;
		isKeyword = false;
	}
	public void setToken(String token)
	{
		this.token = token;
	}
	public void setID()
	{
		isID = true;
	}
	public void setSymbol()
	{
		isSymbol = true;
	}
	public void setKeyword()
	{
		isKeyword = true;
	}
	public void setLiteral()
	{
		isLiteral = true;
	}
	public boolean isLiteral()
	{
		return isLiteral;
	}
	public String getToken()
	{
		return token;
	}
	public boolean isID()
	{
		return isID;
	}
	public boolean isSymbol()
	{
		return isSymbol;
	}
	public boolean isKeyword()
	{
		return isKeyword;
	}
}*/